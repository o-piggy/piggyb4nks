switch ( n ) {
    case 1:
        printf("The number is 1\n");
        break;  //Ditambahin break
    case 2:
        printf("The number is 2\n");
        break;
    default:
        printf("The number is not 1 or 2\n");
        break;
}

